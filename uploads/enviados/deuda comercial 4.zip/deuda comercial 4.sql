/* COnsulta de Deuda Comercia para oc internacionales*/

--select sum(total_recibido-total_pagos) as total, id_moneda from (

select * from (

--consulta que vale
select  oc.nro_orden,cantidad_filas.total as total_filas,montos_filas.total_filas_sin_gastos,montos_filas.total_filas,recibidos.total_recibido,
        pagos.total,cantidad_pagos.cantidad
    from 
    compras.orden_de_compra oc
   join
    (
      select    sum(fila.cantidad) as total ,
                oc.nro_orden 
		from compras.orden_de_compra oc
		join compras.fila using (nro_orden)
		where internacional=1 
		group by oc.nro_orden order by oc.nro_orden
      ) as cantidad_filas on(oc.nro_orden=cantidad_filas.nro_orden and oc.internacional=1)

   join 
    (
     select  oc.nro_orden,sum(fila.precio_unitario*fila.cantidad) as total_filas_sin_gastos,
               sum((fila.precio_unitario*fila.cantidad) + fila.iva + fila.ib + derechos) as total_filas,monto_flete , honorarios_gastos, oc.id_moneda,razon_social as total_filas_con_gastos
               from compras.orden_de_compra oc
               join compras.datos_oc_internacional using (nro_orden)
               join compras.fila using(nro_orden)
               join general.proveedor using(id_proveedor)
               where fila.es_agregado=0   and   proveedor.razon_social not  ilike '%stock%'    and internacional=1
               group by oc.nro_orden,oc.id_moneda,razon_social,monto_flete , honorarios_gastos
               order by nro_orden
    ) as montos_filas  on (montos_filas.nro_orden=oc.nro_orden)

left join
   ( select   sum(
                  case when ent_rec is null then 0 else recibido_entregado.cantidad end ) as cantidad_recibido,
                  (sum(case when ent_rec is null then 0 else recibido_entregado.cantidad end *fila.precio_unitario)) as total_recibido,                     
                  oc.nro_orden
		  from compras.orden_de_compra oc
	          join compras.fila using(nro_orden)
	          join compras.recibido_entregado using(id_fila)
	          where recibido_entregado.ent_rec=1   and fila.es_agregado=0 and internacional=1
	          group by oc.nro_orden order by nro_orden
	         ) as recibidos on (oc.nro_orden=recibidos.nro_orden)
 left  join
        (
        --obtengo cuanto pague de la oc 
	select sum(op.monto) as total, op.id_pago,pago_orden.nro_orden
	              from
                       compras.orden_de_compra oc
                       join  compras.pago_orden using (nro_orden)
                       join  compras.ordenes_pagos op using (id_pago) 
	              where  internacional=1 
                             and ( (not op."n�meroch" is null) or (not op."idd�bito" is null) or (not id_ingreso_egreso is null))
	              group by op.id_pago,pago_orden.nro_orden order by pago_orden.nro_orden
             ) as  pagos on (pagos.nro_orden=oc.nro_orden)		
 left join 
        (
          --obtengo cuandos pagos multiples esta la oc
         select count(pago_orden.id_pago) as cantidad, pago_orden.id_pago
	          from
		       compras.orden_de_compra oc
                       join compras.pago_orden on (oc.nro_orden=pago_orden.nro_orden)
		       join compras.ordenes_pagos op using(id_pago) 
		       where internacional=1 
                             and ( (not op."n�meroch" is null) or (not op."idd�bito" is null) or (not id_ingreso_egreso is null))
		      group by pago_orden.id_pago
	 ) as cantidad_pagos using(id_pago)

) as principal
--where total_pagos > total_recibido --and cantidad_recibido < cantidad_filas
--group by id_moneda